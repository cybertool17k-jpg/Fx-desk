plugins {
    id("com.android.application")
}

android {
    namespace = "com.fxdesk.market"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.fxdesk.market"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.14.0")
}
