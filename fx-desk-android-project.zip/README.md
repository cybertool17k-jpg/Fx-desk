# FX Desk Android app

This Android app bundles the FX Desk website locally and connects to Deriv's public WebSocket and the economic calendar over the internet.

## Build

Open this folder in Android Studio and build the `app` debug variant. The installable APK is created at `app/build/outputs/apk/debug/app-debug.apk`.

The app needs internet access for live prices and calendar updates. Its HTML is bundled in the app, so changes to the website require rebuilding the APK.
